# 1. da kai
file = open("README", "a")

# 2. xie ru
file.write("123 hello")

# 3. guan bi
file.close()