hello_str = "hello shijie"
print(hello_str )

for c in hello_str:
    print(c)