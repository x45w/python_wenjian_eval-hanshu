input_str = input("qing shu ru suan shu ti:")
print(eval(input_str))